﻿namespace FlappyBird
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.scoreLabel = new System.Windows.Forms.Label();
            this.scoreText = new System.Windows.Forms.Label();
            this.obstacleTop = new System.Windows.Forms.PictureBox();
            this.obstacleDown = new System.Windows.Forms.PictureBox();
            this.birdPlayer = new System.Windows.Forms.PictureBox();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.ground = new System.Windows.Forms.PictureBox();
            this.obstacleTop2 = new System.Windows.Forms.PictureBox();
            this.obstacleDown2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.birdPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleTop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleDown2)).BeginInit();
            this.SuspendLayout();
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.Location = new System.Drawing.Point(27, 22);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(100, 31);
            this.scoreLabel.TabIndex = 0;
            this.scoreLabel.Text = "Score: ";
            this.scoreLabel.Click += new System.EventHandler(this.scoreLabel_Click);
            // 
            // scoreText
            // 
            this.scoreText.AutoSize = true;
            this.scoreText.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreText.Location = new System.Drawing.Point(111, 22);
            this.scoreText.Name = "scoreText";
            this.scoreText.Size = new System.Drawing.Size(60, 31);
            this.scoreText.TabIndex = 1;
            this.scoreText.Text = "N/A";
            this.scoreText.Click += new System.EventHandler(this.scoreText_Click);
            // 
            // obstacleTop
            // 
            this.obstacleTop.BackColor = System.Drawing.Color.Red;
            this.obstacleTop.Location = new System.Drawing.Point(413, -18);
            this.obstacleTop.Name = "obstacleTop";
            this.obstacleTop.Size = new System.Drawing.Size(117, 302);
            this.obstacleTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacleTop.TabIndex = 2;
            this.obstacleTop.TabStop = false;
            this.obstacleTop.Click += new System.EventHandler(this.obstacleUp_Click);
            // 
            // obstacleDown
            // 
            this.obstacleDown.BackColor = System.Drawing.Color.Red;
            this.obstacleDown.Location = new System.Drawing.Point(660, 271);
            this.obstacleDown.Name = "obstacleDown";
            this.obstacleDown.Size = new System.Drawing.Size(117, 302);
            this.obstacleDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacleDown.TabIndex = 3;
            this.obstacleDown.TabStop = false;
            this.obstacleDown.Click += new System.EventHandler(this.obstacleDown_Click);
            // 
            // birdPlayer
            // 
            this.birdPlayer.Image = ((System.Drawing.Image)(resources.GetObject("birdPlayer.Image")));
            this.birdPlayer.Location = new System.Drawing.Point(132, 137);
            this.birdPlayer.Name = "birdPlayer";
            this.birdPlayer.Size = new System.Drawing.Size(74, 80);
            this.birdPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.birdPlayer.TabIndex = 4;
            this.birdPlayer.TabStop = false;
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 40;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
            // 
            // ground
            // 
            this.ground.BackColor = System.Drawing.Color.Green;
            this.ground.Location = new System.Drawing.Point(-4, 554);
            this.ground.Name = "ground";
            this.ground.Size = new System.Drawing.Size(1206, 145);
            this.ground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ground.TabIndex = 5;
            this.ground.TabStop = false;
            // 
            // obstacleTop2
            // 
            this.obstacleTop2.BackColor = System.Drawing.Color.Red;
            this.obstacleTop2.Location = new System.Drawing.Point(905, -18);
            this.obstacleTop2.Name = "obstacleTop2";
            this.obstacleTop2.Size = new System.Drawing.Size(117, 302);
            this.obstacleTop2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacleTop2.TabIndex = 6;
            this.obstacleTop2.TabStop = false;
            // 
            // obstacleDown2
            // 
            this.obstacleDown2.BackColor = System.Drawing.Color.Red;
            this.obstacleDown2.Location = new System.Drawing.Point(1151, 271);
            this.obstacleDown2.Name = "obstacleDown2";
            this.obstacleDown2.Size = new System.Drawing.Size(117, 302);
            this.obstacleDown2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacleDown2.TabIndex = 7;
            this.obstacleDown2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1166, 600);
            this.Controls.Add(this.ground);
            this.Controls.Add(this.obstacleDown2);
            this.Controls.Add(this.obstacleTop2);
            this.Controls.Add(this.birdPlayer);
            this.Controls.Add(this.obstacleDown);
            this.Controls.Add(this.obstacleTop);
            this.Controls.Add(this.scoreText);
            this.Controls.Add(this.scoreLabel);
            this.Name = "Form1";
            this.Text = "Flappy Bird";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.onKeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.onKeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.obstacleTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.birdPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleTop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacleDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Label scoreText;
        private System.Windows.Forms.PictureBox obstacleTop;
        private System.Windows.Forms.PictureBox obstacleDown;
        private System.Windows.Forms.PictureBox birdPlayer;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.PictureBox ground;
        private System.Windows.Forms.PictureBox obstacleTop2;
        private System.Windows.Forms.PictureBox obstacleDown2;
    }
}

