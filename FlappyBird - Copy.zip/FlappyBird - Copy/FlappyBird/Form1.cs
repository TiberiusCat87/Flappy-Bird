﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBird
{
    public partial class Form1 : Form
    {

        int pipeSpd = 5;
        int birdSpd = 10; // Gravity
        int jumpStrength = 10;
        int score = 0;

        bool speedInc = false;
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            gameTimer.Start();
        }

        private void scoreLabel_Click(object sender, EventArgs e)
        {

        }

        private void scoreText_Click(object sender, EventArgs e)
        {

        }

        private void onKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                birdSpd = 10;
            }
        }

        private void onKeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Up)
            {
                birdSpd = -10;
            }
        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {
            birdPlayer.Top = birdPlayer.Top + birdSpd;

            // Affect obstacles margin
            obstacleDown.Left = obstacleDown.Left - pipeSpd;
            obstacleTop.Left = obstacleTop.Left - pipeSpd;
            obstacleDown2.Left = obstacleDown2.Left - pipeSpd;
            obstacleTop2.Left = obstacleTop2.Left - pipeSpd;

            // Scoring
            scoreText.Text = score.ToString();

            // Spawn Obstacles Again
            if(obstacleDown.Left < -150)
            {
                obstacleDown.Left = 1400;
                score++;
            }
            if (obstacleTop.Left < -150)
            {
                obstacleTop.Left = 1400;
                score++;
            }
            if (obstacleDown2.Left < -150)
            {
                obstacleDown2.Left = 1400;
                score++;
            }
            if (obstacleTop2.Left < -150)
            {
                obstacleTop2.Left = 1400;
                score++;
            }


            if (birdPlayer.Bounds.IntersectsWith(obstacleTop.Bounds)|| birdPlayer.Bounds.IntersectsWith(obstacleDown.Bounds)|| birdPlayer.Bounds.IntersectsWith(ground.Bounds)|| birdPlayer.Top < -25|| birdPlayer.Bounds.IntersectsWith(obstacleTop2.Bounds)|| birdPlayer.Bounds.IntersectsWith(obstacleDown2.Bounds))
            {
                if(score>0)
                {
                    score--;
                }
                else
                {
                    gameOver();
                }
            }

            if (score >= 1 && !speedInc && gameTimer.Interval >= 30)
            {
                gameTimer.Interval = 40 - score;
            }
        }
        private void gameOver()
        {
            birdPlayer.Top = 2929292;
            gameTimer.Stop();
            scoreText.Text = "�💀�";
        }

        private void obstacleDown_Click(object sender, EventArgs e)
        {

        }

        private void obstacleUp_Click(object sender, EventArgs e)
        {

        }
    }
}
